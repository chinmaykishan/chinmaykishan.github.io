import { motion } from 'framer-motion';
import { Search, HelpCircle, Wrench, MessageCircle, Download, MapPin, Activity } from 'lucide-react';
import { Navbar } from '@/components/layout/Navbar';
import { FullScreenMenu } from '@/components/layout/FullScreenMenu';
import { useState } from 'react';
import { ANIMATION_CONFIG } from '@/lib/animations';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from '@/components/ui/accordion';

const supportCategories = [
  { title: 'Product Guide', icon: HelpCircle },
  { title: 'Troubleshooting', icon: Wrench },
  { title: 'FAQs', icon: MessageCircle },
  { title: 'Software Download', icon: Download },
  { title: 'Service Centres', icon: MapPin },
  { title: 'Product Status', icon: Activity },
];

const faqItems = [
  {
    question: 'How to install the latest Phone OS via OTA?',
    answer: 'To install the latest Phone OS via OTA, go to Settings > System > System Update. If an update is available, tap Download and Install. Make sure your device is connected to Wi-Fi and has at least 50% battery.',
  },
  {
    question: 'How to turn on Android auto on my Nothing phone?',
    answer: 'To enable Android Auto, connect your phone to your car via USB. Open the Android Auto app and follow the on-screen instructions. You may need to enable Android Auto in your car\'s settings.',
  },
  {
    question: 'How to pair my Nothing Ear or Ear (a) with my phone?',
    answer: 'Open the charging case with the earbuds inside. Press and hold the setup button on the case until the LED blinks white. Go to your phone\'s Bluetooth settings and select your Nothing Ear from the available devices.',
  },
  {
    question: 'How to activate the ChatGPT feature on my Nothing Headphone?',
    answer: 'Ensure your Nothing Headphone is connected to your phone via the Nothing X app. Go to the app settings and enable the ChatGPT integration. Follow the prompts to link your OpenAI account.',
  },
  {
    question: 'How to use the screen widgets on my Nothing phone?',
    answer: 'Long press on an empty area of your home screen, then tap Widgets. Browse the available widgets and tap and hold to add one to your home screen. You can resize and reposition widgets as needed.',
  },
];

export function Support() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <Navbar onMenuOpen={() => setMenuOpen(true)} />
      <FullScreenMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />

      {/* Hero Section */}
      <section className="pt-[60px] relative bg-gradient-to-b from-gray-50 to-white">
        <div className="max-w-6xl mx-auto px-4 md:px-8 py-12 md:py-20">
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            {/* Text Content */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: ANIMATION_CONFIG.easing.smooth }}
            >
              <h1 className="font-space-grotesk text-3xl md:text-4xl font-light text-nothing-black mb-4">
                Support Centre
              </h1>
              <p className="font-inter text-sm md:text-base text-nothing-gray leading-relaxed mb-6">
                Learn more about your Nothing products, find answers, troubleshoot problems, request help and more.
              </p>

              {/* Search Bar */}
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-nothing-gray" strokeWidth={1.5} />
                <input
                  type="text"
                  placeholder="Search"
                  className="w-full pl-11 pr-4 py-3 bg-white border border-nothing-border rounded-full font-inter text-sm focus:outline-none focus:ring-2 focus:ring-nothing-black/10 transition-all duration-200"
                />
              </div>
            </motion.div>

            {/* Product Image */}
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2, ease: ANIMATION_CONFIG.easing.smooth }}
              className="hidden md:block"
            >
              <img
                src="/images/phone-3a.jpg"
                alt="Nothing Phone"
                className="w-full max-w-sm mx-auto object-contain"
              />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Help Categories */}
      <section className="py-12 md:py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: ANIMATION_CONFIG.easing.smooth }}
            className="font-space-grotesk text-xl md:text-2xl font-light text-nothing-black mb-8"
          >
            How Can We Help You?
          </motion.h2>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3 md:gap-4">
            {supportCategories.map((category, index) => (
              <motion.button
                key={category.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.05,
                  ease: ANIMATION_CONFIG.easing.smooth,
                }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="flex items-center justify-center gap-2 md:gap-3 px-4 md:px-6 py-3 md:py-4 border border-nothing-border rounded-full hover:bg-nothing-black hover:text-white hover:border-nothing-black transition-all duration-200 group"
              >
                <category.icon className="w-4 h-4" strokeWidth={1.5} />
                <span className="font-space-mono text-[10px] md:text-xs tracking-[0.05em]">
                  {category.title}
                </span>
              </motion.button>
            ))}
          </div>
        </div>
      </section>

      {/* Popular Questions */}
      <section className="py-12 md:py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: ANIMATION_CONFIG.easing.smooth }}
            className="font-space-grotesk text-xl md:text-2xl font-light text-nothing-black mb-8"
          >
            Popular Questions
          </motion.h2>

          <Accordion type="single" collapsible className="space-y-2">
            {faqItems.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{
                  duration: 0.5,
                  delay: index * 0.05,
                  ease: ANIMATION_CONFIG.easing.smooth,
                }}
              >
                <AccordionItem value={`item-${index}`} className="bg-white border border-nothing-border rounded-lg px-4 md:px-6">
                  <AccordionTrigger className="py-4 text-left font-inter text-sm md:text-base text-nothing-black hover:no-underline">
                    {item.question}
                  </AccordionTrigger>
                  <AccordionContent className="pb-4 font-inter text-sm text-nothing-gray leading-relaxed">
                    {item.answer}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </div>
      </section>

      {/* Contact Section */}
      <section className="py-12 md:py-16 bg-white">
        <div className="max-w-6xl mx-auto px-4 md:px-8">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: ANIMATION_CONFIG.easing.smooth }}
            className="flex flex-col md:flex-row md:items-center md:justify-between gap-6"
          >
            <div>
              <h2 className="font-space-grotesk text-xl md:text-2xl font-light text-nothing-black mb-2">
                Contact Us
              </h2>
              <p className="font-inter text-sm text-nothing-gray">
                Feel free to send us an email for further support. Our experts are on-hand to help.
              </p>
            </div>

            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              className="btn-primary whitespace-nowrap"
            >
              SEND US A MESSAGE
            </motion.button>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

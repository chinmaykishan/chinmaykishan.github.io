export const ANIMATION_CONFIG = {
  easing: {
    smooth: [0.16, 1, 0.3, 1] as const,
    bounce: [0.34, 1.56, 0.64, 1] as const,
    out: [0, 0, 0.2, 1] as const,
  },
  duration: {
    micro: 0.15,
    fast: 0.3,
    normal: 0.5,
    slow: 0.8,
  },
  stagger: {
    menu: 0.05,
    sections: 0.1,
    products: 0.1,
  },
};

export const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: ANIMATION_CONFIG.easing.smooth },
};

export const fadeIn = {
  initial: { opacity: 0 },
  animate: { opacity: 1 },
  transition: { duration: 0.6, ease: ANIMATION_CONFIG.easing.out },
};

export const scaleIn = {
  initial: { opacity: 0, scale: 0.95 },
  animate: { opacity: 1, scale: 1 },
  transition: { duration: 0.8, ease: ANIMATION_CONFIG.easing.smooth },
};

export const slideDown = {
  initial: { opacity: 0, y: -20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, ease: ANIMATION_CONFIG.easing.out },
};

export const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: ANIMATION_CONFIG.stagger.menu,
    },
  },
};

export const menuItem = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, ease: ANIMATION_CONFIG.easing.smooth },
};

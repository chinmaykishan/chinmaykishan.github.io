import { useState } from 'react';
import { Navbar } from '@/components/layout/Navbar';
import { FullScreenMenu } from '@/components/layout/FullScreenMenu';
import { Footer } from '@/components/layout/Footer';
import { HeroSection } from '@/components/sections/HeroSection';
import { Phone4aSection } from '@/components/sections/Phone4aSection';
import { Phone3aSection } from '@/components/sections/Phone3aSection';
import { HeadphonesSection } from '@/components/sections/HeadphonesSection';
import { Phone3aLiteSection } from '@/components/sections/Phone3aLiteSection';
import { Support } from '@/pages/Support';
import './App.css';

function HomePage() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-white">
      <Navbar onMenuOpen={() => setMenuOpen(true)} />
      <FullScreenMenu isOpen={menuOpen} onClose={() => setMenuOpen(false)} />
      
      <main>
        <HeroSection />
        <Phone4aSection />
        <Phone3aSection />
        <HeadphonesSection />
        <Phone3aLiteSection />
      </main>

      <Footer />
    </div>
  );
}

function App() {
  // Simple routing based on hash
  const hash = window.location.hash;
  
  if (hash === '#support') {
    return <Support />;
  }

  return <HomePage />;
}

export default App;

export interface ProductData {
  id: string;
  headline: string;
  productName: string;
  ctaText: string;
  ctaLink: string;
  mainImage: string;
  thumbnailImage?: string;
  bgVariant: 'light' | 'dark';
}

export interface NavItem {
  label: string;
  href: string;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface SupportCategory {
  title: string;
  icon: string;
}

import { motion } from 'framer-motion';
import { ANIMATION_CONFIG } from '@/lib/animations';

interface ProductCardProps {
  headline: string;
  productName: string;
  ctaText: string;
  ctaLink?: string;
  thumbnailImage?: string;
  variant?: 'light' | 'dark';
  delay?: number;
}

export function ProductCard({
  headline,
  productName,
  ctaText,
  ctaLink = '#',
  thumbnailImage,
  variant = 'light',
  delay = 0.4,
}: ProductCardProps) {
  const isDark = variant === 'dark';

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{
        duration: 0.6,
        delay,
        ease: ANIMATION_CONFIG.easing.smooth,
      }}
      className={`w-full max-w-[320px] md:max-w-[380px] ${
        isDark ? 'product-card-dark' : 'product-card'
      } p-4 md:p-5`}
    >
      <div className="flex items-center justify-between gap-4">
        {/* Text Content */}
        <div className="flex flex-col gap-1">
          <h3
            className={`font-space-grotesk text-base md:text-lg font-light ${
              isDark ? 'text-white/90' : 'text-nothing-black'
            }`}
          >
            {headline}
          </h3>
          <p
            className={`font-space-mono text-[11px] md:text-xs tracking-[0.05em] ${
              isDark ? 'text-white/60' : 'text-nothing-gray'
            }`}
          >
            {productName}
          </p>
        </div>

        {/* Thumbnail + CTA */}
        <div className="flex flex-col items-end gap-2">
          {thumbnailImage && (
            <div className="w-10 h-14 md:w-12 md:h-16 relative">
              <img
                src={thumbnailImage}
                alt={productName}
                className="w-full h-full object-contain"
              />
            </div>
          )}
          <a
            href={ctaLink}
            className={`px-3 py-1.5 rounded-full font-space-mono text-[9px] md:text-[10px] font-medium tracking-[0.08em] uppercase transition-all duration-150 hover:scale-[1.02] ${
              isDark
                ? 'bg-white/10 text-white/80 border border-white/20 hover:bg-white/20'
                : 'bg-nothing-black/5 text-nothing-black border border-nothing-black/10 hover:bg-nothing-black/10'
            }`}
          >
            {ctaText}
          </a>
        </div>
      </div>
    </motion.div>
  );
}

import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { ANIMATION_CONFIG } from '@/lib/animations';

interface AnimatedImageProps {
  src: string;
  alt: string;
  className?: string;
  parallaxOffset?: number;
  scaleOnScroll?: boolean;
}

export function AnimatedImage({
  src,
  alt,
  className = '',
  parallaxOffset = 50,
  scaleOnScroll = false,
}: AnimatedImageProps) {
  const ref = useRef<HTMLDivElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ['start end', 'end start'],
  });

  const y = useTransform(scrollYProgress, [0, 1], [parallaxOffset, -parallaxOffset]);
  const scale = useTransform(scrollYProgress, [0, 0.5, 1], [0.95, 1, scaleOnScroll ? 1.05 : 1]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0.6, 1, 1, 0.6]);

  return (
    <div ref={ref} className="relative overflow-hidden">
      <motion.div
        style={{ y, scale, opacity }}
        transition={{ duration: 0.1 }}
        className="will-change-transform"
      >
        <img
          src={src}
          alt={alt}
          className={`w-full h-full object-contain ${className}`}
          loading="lazy"
        />
      </motion.div>
    </div>
  );
}

interface FadeInImageProps {
  src: string;
  alt: string;
  className?: string;
  delay?: number;
}

export function FadeInImage({ src, alt, className = '', delay = 0 }: FadeInImageProps) {
  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: '-100px' }}
      transition={{
        duration: 0.8,
        delay,
        ease: ANIMATION_CONFIG.easing.smooth,
      }}
      className="will-change-transform"
    >
      <img
        src={src}
        alt={alt}
        className={`w-full h-full object-contain ${className}`}
        loading="lazy"
      />
    </motion.div>
  );
}

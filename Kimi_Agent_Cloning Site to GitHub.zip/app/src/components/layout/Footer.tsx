import { motion } from 'framer-motion';
import { HelpCircle, Mail, MapPin, ChevronDown } from 'lucide-react';
import { fadeInUp, ANIMATION_CONFIG } from '@/lib/animations';

const mainNavItems = [
  { label: 'SHOP ALL', href: '#' },
  { label: 'PHONES', href: '#' },
  { label: 'AUDIO', href: '#' },
  { label: 'WATCHES', href: '#' },
  { label: 'ACCESSORIES', href: '#' },
  { label: 'CMF', href: '#' },
];

const bottomLinks = [
  { label: 'PLAYGROUND', href: '#' },
  { label: 'CONTACT', href: '#' },
  { label: 'CAREERS', href: '#' },
  { label: 'LEGAL', href: '#' },
  { label: 'PRIVACY', href: '#' },
  { label: 'INSTAGRAM', href: '#' },
  { label: 'YOUTUBE', href: '#' },
  { label: 'X', href: '#' },
  { label: 'TIKTOK', href: '#' },
];

export function Footer() {
  return (
    <footer className="relative bg-nothing-black min-h-[80vh] flex flex-col">
      {/* Dotted Grid Background */}
      <div className="absolute inset-0 dotted-grid-dark" />

      {/* Main Content */}
      <div className="relative z-10 flex-1 flex flex-col items-center justify-center px-6 py-20">
        {/* Main Navigation */}
        <motion.nav
          initial={fadeInUp.initial}
          whileInView={fadeInUp.animate}
          viewport={{ once: true, margin: '-100px' }}
          transition={{ ...fadeInUp.transition, duration: 0.8 }}
          className="flex flex-col items-center gap-3 md:gap-4"
        >
          {mainNavItems.map((item, index) => (
            <motion.a
              key={item.label}
              href={item.href}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{
                duration: 0.5,
                delay: index * 0.05,
                ease: ANIMATION_CONFIG.easing.smooth,
              }}
              className="font-space-mono text-xl md:text-2xl tracking-[0.15em] text-white/90 hover:text-white transition-colors duration-200 relative group"
            >
              <span className="relative">
                {item.label}
                <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-white transition-all duration-300 group-hover:w-full" />
              </span>
            </motion.a>
          ))}
        </motion.nav>

        {/* Secondary Actions */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4, duration: 0.5 }}
          className="mt-12 md:mt-16 flex flex-col items-center gap-3"
        >
          <button className="flex items-center gap-3 px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors duration-200">
            <HelpCircle className="w-4 h-4 text-white/70" strokeWidth={1.5} />
            <span className="font-space-mono text-[11px] tracking-[0.1em] text-white/70">
              SUPPORT
            </span>
          </button>

          <button className="flex items-center gap-3 px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors duration-200">
            <Mail className="w-4 h-4 text-white/70" strokeWidth={1.5} />
            <span className="font-space-mono text-[11px] tracking-[0.1em] text-white/70">
              NEWSLETTER
            </span>
          </button>

          <button className="flex items-center gap-3 px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors duration-200">
            <MapPin className="w-4 h-4 text-white/70" strokeWidth={1.5} />
            <span className="font-space-mono text-[11px] tracking-[0.1em] text-white/70">
              STORE: INDIA
            </span>
          </button>

          <button className="flex items-center gap-3 px-4 py-2.5 bg-white/5 border border-white/10 rounded-lg hover:bg-white/10 transition-colors duration-200">
            <span className="font-space-mono text-[11px] tracking-[0.1em] text-white/70">
              LANGUAGES: EN
            </span>
            <ChevronDown className="w-3 h-3 text-white/70" strokeWidth={1.5} />
          </button>
        </motion.div>
      </div>

      {/* Bottom Bar */}
      <motion.div
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        viewport={{ once: true }}
        transition={{ delay: 0.6, duration: 0.5 }}
        className="relative z-10 border-t border-white/10 py-4 px-4"
      >
        <div className="flex items-center justify-center gap-3 md:gap-5 flex-wrap">
          {bottomLinks.map((link) => (
            <a
              key={link.label}
              href={link.href}
              className="font-space-mono text-[9px] md:text-[10px] tracking-[0.08em] text-white/50 hover:text-white/80 transition-colors duration-200"
            >
              {link.label}
            </a>
          ))}
        </div>
      </motion.div>
    </footer>
  );
}

interface DottedGridProps {
  variant?: 'light' | 'dark';
  className?: string;
}

export function DottedGrid({ variant = 'light', className = '' }: DottedGridProps) {
  return (
    <div
      className={`absolute inset-0 pointer-events-none ${
        variant === 'light' ? 'dotted-grid-light' : 'dotted-grid-dark'
      } ${className}`}
      aria-hidden="true"
    />
  );
}

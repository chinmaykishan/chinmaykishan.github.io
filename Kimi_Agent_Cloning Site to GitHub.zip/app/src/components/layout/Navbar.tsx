import { motion } from 'framer-motion';
import { Menu } from 'lucide-react';
import { slideDown } from '@/lib/animations';

interface NavbarProps {
  onMenuOpen: () => void;
}

export function Navbar({ onMenuOpen }: NavbarProps) {
  return (
    <motion.header
      initial={slideDown.initial}
      animate={slideDown.animate}
      transition={slideDown.transition}
      className="fixed top-0 left-0 right-0 z-50 h-[60px] flex items-center justify-between px-4 md:px-6 bg-white/80 backdrop-blur-md"
    >
      {/* Menu Button */}
      <button
        onClick={onMenuOpen}
        className="p-2 -ml-2 hover:opacity-70 transition-opacity duration-200"
        aria-label="Open menu"
      >
        <Menu className="w-5 h-5 text-nothing-black" strokeWidth={1.5} />
      </button>

      {/* Logo */}
      <div className="absolute left-1/2 -translate-x-1/2">
        <span className="font-space-mono text-sm tracking-[0.1em] text-nothing-black">
          NOTHING (R)
        </span>
      </div>

      {/* Spacer for balance */}
      <div className="w-9" />
    </motion.header>
  );
}

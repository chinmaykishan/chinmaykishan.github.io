import { motion, AnimatePresence } from 'framer-motion';
import { X } from 'lucide-react';
import { staggerContainer, menuItem, ANIMATION_CONFIG } from '@/lib/animations';

interface FullScreenMenuProps {
  isOpen: boolean;
  onClose: () => void;
}

const mainNavItems = [
  { label: 'SHOP ALL', href: '#' },
  { label: 'PHONES', href: '#' },
  { label: 'AUDIO', href: '#' },
  { label: 'WATCHES', href: '#' },
  { label: 'ACCESSORIES', href: '#' },
  { label: 'CMF', href: '#' },
];

const footerNavItems = [
  { label: 'ACCOUNT', href: '#' },
  { label: 'SUPPORT', href: '#support' },
  { label: 'COMMUNITY', href: '#' },
  { label: 'PLAYGROUND', href: '#' },
];

export function FullScreenMenu({ isOpen, onClose }: FullScreenMenuProps) {
  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.3, ease: ANIMATION_CONFIG.easing.out }}
          className="fixed inset-0 z-[100] bg-white/98 backdrop-blur-xl"
        >
          {/* Close Button */}
          <button
            onClick={onClose}
            className="absolute top-4 left-4 md:left-6 p-2 hover:opacity-70 transition-opacity duration-200"
            aria-label="Close menu"
          >
            <X className="w-5 h-5 text-nothing-black" strokeWidth={1.5} />
          </button>

          {/* Logo */}
          <div className="absolute top-4 left-1/2 -translate-x-1/2">
            <span className="font-space-mono text-sm tracking-[0.1em] text-nothing-black">
              NOTHING (R)
            </span>
          </div>

          {/* Navigation Content */}
          <div className="h-full flex flex-col items-center justify-center px-6">
            {/* Main Navigation */}
            <motion.nav
              variants={staggerContainer}
              initial="initial"
              animate="animate"
              className="flex flex-col items-center gap-4 md:gap-5"
            >
              {mainNavItems.map((item, index) => (
                <motion.a
                  key={item.label}
                  href={item.href}
                  variants={menuItem}
                  custom={index}
                  onClick={onClose}
                  className="font-space-mono text-2xl md:text-3xl tracking-[0.15em] text-nothing-black hover:opacity-60 transition-opacity duration-200 relative group"
                >
                  <span className="relative">
                    {item.label}
                    <span className="absolute bottom-0 left-0 w-0 h-[1px] bg-nothing-black transition-all duration-300 group-hover:w-full" />
                  </span>
                </motion.a>
              ))}
            </motion.nav>

            {/* Footer Navigation */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.4, duration: 0.4 }}
              className="absolute bottom-8 left-0 right-0"
            >
              <div className="flex items-center justify-center gap-4 md:gap-6 flex-wrap px-4">
                {footerNavItems.map((item) => (
                  <a
                    key={item.label}
                    href={item.href}
                    onClick={onClose}
                    className="font-space-mono text-[10px] md:text-xs tracking-[0.1em] text-nothing-gray hover:text-nothing-black transition-colors duration-200"
                  >
                    {item.label}
                  </a>
                ))}
              </div>
            </motion.div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

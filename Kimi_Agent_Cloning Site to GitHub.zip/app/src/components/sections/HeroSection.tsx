import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { DottedGrid } from '@/components/layout/DottedGrid';
import { ProductCard } from '@/components/shared/ProductCard';
import { ANIMATION_CONFIG } from '@/lib/animations';

export function HeroSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end start'],
  });

  const imageY = useTransform(scrollYProgress, [0, 1], [0, -80]);
  const imageScale = useTransform(scrollYProgress, [0, 0.5, 1], [1, 1.02, 1.05]);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen bg-white overflow-hidden pt-[60px]"
    >
      {/* Dotted Grid Background */}
      <DottedGrid variant="light" />

      {/* Content Container */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[calc(100vh-60px)] px-4 py-8">
        {/* Product Image */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{
            duration: 0.8,
            ease: ANIMATION_CONFIG.easing.smooth,
          }}
          style={{ y: imageY, scale: imageScale }}
          className="relative w-full max-w-4xl mx-auto will-change-transform"
        >
          <img
            src="/images/hero-phones.jpg"
            alt="Nothing Phone (4a) Pro in three colors - pink, silver, and black"
            className="w-full h-auto object-contain"
            loading="eager"
          />
        </motion.div>

        {/* Floating Product Card */}
        <div className="absolute bottom-8 md:bottom-16 left-1/2 -translate-x-1/2 w-full px-4">
          <div className="flex justify-center">
            <ProductCard
              headline="It's metal now"
              productName="phone (4a) pro"
              ctaText="PRE-ORDER"
              thumbnailImage="/images/phone-black.jpg"
              variant="light"
              delay={0.4}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

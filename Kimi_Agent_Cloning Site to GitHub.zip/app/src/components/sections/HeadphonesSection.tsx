import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { DottedGrid } from '@/components/layout/DottedGrid';
import { ProductCard } from '@/components/shared/ProductCard';
import { ANIMATION_CONFIG } from '@/lib/animations';

export function HeadphonesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  });

  const imageY = useTransform(scrollYProgress, [0, 1], [40, -40]);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen bg-gradient-to-b from-gray-50 to-white overflow-hidden py-16 md:py-24"
    >
      {/* Dotted Grid Background */}
      <DottedGrid variant="light" />

      {/* Content Container */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[80vh] px-4">
        {/* Product Image - Headphones with floating animation */}
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{
            duration: 0.8,
            ease: ANIMATION_CONFIG.easing.smooth,
          }}
          style={{ y: imageY }}
          className="relative w-full max-w-lg mx-auto will-change-transform"
        >
          <motion.div
            animate={{ y: [0, -15, 0] }}
            transition={{
              duration: 5,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          >
            <img
              src="/images/headphones.jpg"
              alt="Nothing Headphones with transparent design"
              className="w-full h-auto object-contain"
              loading="lazy"
            />
          </motion.div>
        </motion.div>

        {/* Floating Product Card */}
        <div className="mt-8 md:mt-12 w-full px-4">
          <div className="flex justify-center">
            <ProductCard
              headline="Come to Play"
              productName="headphones (1)"
              ctaText="DISCOVER"
              thumbnailImage="/images/headphones.jpg"
              variant="light"
              delay={0.2}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

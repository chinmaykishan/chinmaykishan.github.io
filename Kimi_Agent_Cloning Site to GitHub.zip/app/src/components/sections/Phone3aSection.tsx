import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { DottedGrid } from '@/components/layout/DottedGrid';
import { ProductCard } from '@/components/shared/ProductCard';
import { ANIMATION_CONFIG } from '@/lib/animations';

export function Phone3aSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  });

  const imageScale = useTransform(scrollYProgress, [0, 0.5, 1], [0.9, 1, 1.05]);
  const imageY = useTransform(scrollYProgress, [0, 1], [30, -30]);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen overflow-hidden py-16 md:py-24"
      style={{
        background: 'linear-gradient(180deg, #0a0a0a 0%, #1a1f2e 50%, #0f1419 100%)',
      }}
    >
      {/* Dotted Grid Background */}
      <DottedGrid variant="dark" />

      {/* Content Container */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[80vh] px-4">
        {/* Product Image - Phone 3a */}
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          whileInView={{ opacity: 1, scale: 1 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{
            duration: 1,
            ease: ANIMATION_CONFIG.easing.smooth,
          }}
          style={{ scale: imageScale, y: imageY }}
          className="relative w-full max-w-md mx-auto will-change-transform"
        >
          <img
            src="/images/phone-3a.jpg"
            alt="Nothing Phone (3a) with transparent back design"
            className="w-full h-auto object-contain"
            loading="lazy"
          />
        </motion.div>

        {/* Floating Product Card */}
        <div className="mt-8 md:mt-12 w-full px-4">
          <div className="flex justify-center">
            <ProductCard
              headline="Come to Play"
              productName="phone (3a)"
              ctaText="DISCOVER"
              thumbnailImage="/images/phone-black.jpg"
              variant="dark"
              delay={0.2}
            />
          </div>
        </div>
      </div>
    </section>
  );
}

import { motion, useScroll, useTransform } from 'framer-motion';
import { useRef } from 'react';
import { DottedGrid } from '@/components/layout/DottedGrid';
import { ProductCard } from '@/components/shared/ProductCard';
import { ANIMATION_CONFIG } from '@/lib/animations';

export function Phone3aLiteSection() {
  const sectionRef = useRef<HTMLElement>(null);
  
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start end', 'end start'],
  });

  const imageY = useTransform(scrollYProgress, [0, 1], [30, -30]);
  const imageRotate = useTransform(scrollYProgress, [0, 1], [1, -1]);

  return (
    <section
      ref={sectionRef}
      className="relative min-h-screen bg-white overflow-hidden py-16 md:py-24"
    >
      {/* Dotted Grid Background */}
      <DottedGrid variant="light" />

      {/* Content Container */}
      <div className="relative z-10 flex flex-col items-center justify-center min-h-[80vh] px-4">
        {/* Product Image - Floating Phones */}
        <motion.div
          initial={{ opacity: 0, y: 40, rotate: 2 }}
          whileInView={{ opacity: 1, y: 0, rotate: 0 }}
          viewport={{ once: true, margin: '-100px' }}
          transition={{
            duration: 0.8,
            ease: ANIMATION_CONFIG.easing.smooth,
          }}
          style={{ y: imageY, rotate: imageRotate }}
          className="relative w-full max-w-4xl mx-auto will-change-transform"
        >
          <img
            src="/images/phones-floating.jpg"
            alt="Nothing Phone (3a) Lite in black and white"
            className="w-full h-auto object-contain"
            loading="lazy"
          />
        </motion.div>

        {/* Floating Product Card */}
        <div className="mt-8 md:mt-12 w-full px-4">
          <div className="flex justify-center">
            <ProductCard
              headline="Light up the everyday"
              productName="phone (3a) lite"
              ctaText="DISCOVER"
              thumbnailImage="/images/phone-black.jpg"
              variant="light"
              delay={0.2}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
